$(document).ready(function () {
  // fullpage customization
  $('#fullpage').fullpage({
    sectionSelector: '.section',
    navigation: false,
    slidesNavigation: true,
    css3: true,
    controlArrows: false,
  });
});
